package com.example.design_to_spec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
