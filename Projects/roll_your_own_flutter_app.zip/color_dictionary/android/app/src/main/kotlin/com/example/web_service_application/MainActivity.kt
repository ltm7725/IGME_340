package com.example.web_service_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
