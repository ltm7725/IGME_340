class ColorResult {
  String name = "";
  String hex = "";
  Map rgb = {
    "r": 0,
    "g": 0,
    "b": 0
  };
  Map hsl = {
    "h": 0,
    "s": 0,
    "l": 0
  };
}