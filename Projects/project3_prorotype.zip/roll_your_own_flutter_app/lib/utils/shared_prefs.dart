import 'package:flutter/material.dart';
import '../main.dart';
import 'package:flutter_color_utils/flutter_color_utils.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';

/**
 * Updates SharedPreferences whenever an option or menu displayed is changed,
 * so that when the app restarts it can come directly back to where the user left off.
 *
 * @author L Mavroudakis
 * @version 1.0.0
 */
void updateSharedPrefs(void Function(bool) updateMainColor,
    void Function(bool) updateMenuState, void Function(bool) toggleRGBorHSL) {
  myPrefs.setString("resultsNum", selectedClosestAmt.toString());
  myPrefs.setString("lastColor", colorToHex(currentColor));
  myPrefs.setString("colorList", selectedListKey.toString());
  myPrefs.setString("rgbOrHsl", useRGB.toString());
  myPrefs.setString("menu", firstMenuSelected.toString());
  myPrefs.setString("sort", selectedSortMethod.toString());
  myPrefs.setString("ascending", orderButtonBools[0].toString());
}

/**s
 * Updates variables and calls functions when the app restarts that allows it to 
 * come directly back to where the user left off if used before. If not, uses
 * default values/options.
 *
 * @author L Mavroudakis
 * @version 1.0.0
 */
void restoreSharedPrefs(void Function(bool) updateMainColor,
    void Function(bool) updateMenuState, void Function(bool) toggleRGBorHSL) {
  if (myPrefs.getString("resultsNum") != null) {
    selectedClosestAmt = myPrefs.getString("resultsNum").toString();
  }
  if (myPrefs.getString("lastColor") != null) {
    currentColor = HexColor(myPrefs.getString("lastColor").toString());
    updateMainColor(true);
  } else
    updateMainColor(false);
  if (myPrefs.getString("colorList") != null) {
    selectedListKey = myPrefs.getString("colorList").toString();
  }
  if (myPrefs.getString("menu") != null) {
    if (myPrefs.getString("menu").toString() == "false") {
      firstMenuSelected = false;
      updateMenuState(resultsReady);
    }
  }
  if (myPrefs.getString("sort") != null) {
    selectedSortMethod = int.parse(myPrefs.getString("sort").toString());
  }
  if (myPrefs.getString("ascending") != null) {
    if (myPrefs.getString("ascending").toString() == "true") {
      orderButtonBools[0] = true;
      orderButtonBools[1] = false;
    }
  }
  if (myPrefs.getString("rgbOrHsl") != null) {
    if (myPrefs.getString("rgbOrHsl").toString() == "false") {
      toggleRGBorHSL(true);
    }
  }
}
