import 'package:flutter/material.dart';
import '../main.dart';
import 'builders.dart';
import 'http.dart';
import 'analysis.dart';

/**
 * Calls the building for all color containers in the "Palette Colors" menu.
 *
 * @author L Mavroudakis
 * @version 1.0.0
 */
void updatePaletteResults(
    BuildContext context, void Function(Map) paletteResultSetState) {
  closestContainer =
      buildPaletteResult(200, 300, context, paletteResultSetState, mainData);
  complimentaryContainer = buildPaletteResult(
      200, 300, context, paletteResultSetState, complimentaryColor);
  triadicContainer1 = buildPaletteResult(
      200, 300, context, paletteResultSetState, triadicColor1);
  triadicContainer2 = buildPaletteResult(
      200, 300, context, paletteResultSetState, triadicColor2);
  tetradicContainer1 = buildPaletteResult(
      200, 300, context, paletteResultSetState, tetradicColor1);
  tetradicContainer2 = buildPaletteResult(
      200, 300, context, paletteResultSetState, tetradicColor2);
  tetradicContainer3 = buildPaletteResult(
      200, 300, context, paletteResultSetState, tetradicColor3);
}

/**
 * Calls analysis for all colors in a list based on search/sort queries,
 * and builds all containers to be displayed in "Other Closest Colors" menu,
 * returned to be placed into the Scaffold structure.
 *
 * @author L Mavroudakis
 * @version 1.0.0
 */
List<Padding> updateClosestResults(
    BuildContext context,
    void Function(bool) updateMenuState,
    void Function(bool) updateMainColor,
    void Function(Color) closestResultSetState,
    void Function(dynamic) launchHTTPSetState) {
  List<Padding> list = [];

  analyzeClosestColors();

  String t = selectedClosestAmt.toString();

  if (selectedClosestAmt != null && selectedSortMethod != null) {
    for (int i = 0; i < int.parse(t); i++) {
      if (i > allClosestColors.length - 1) break;
      list.add(buildClosestResult(allClosestColors[i], context, updateMenuState,
          updateMainColor, closestResultSetState, launchHTTPSetState));
    }
  }

  closestLoading = false;
  updateMenuState(resultsReady);
  return list;
}
