import 'package:flutter/material.dart';
import '../main.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:flutter_color_utils/flutter_color_utils.dart';
import 'package:flutter/services.dart';
import 'http.dart';
import 'analysis.dart';

/**
 * Builds a Container to be placed in the "Palette Colors" menu,
 * with all the color attributes of the given data and with
 * a specific size to the Container.
 *
 * @author L Mavroudakis
 * @version 1.0.0
 * @param theHeight - Intended Container height
 * @param theWidth - Intended Container width
 * @param data - parsed JSON data for color to create Container based on
 */
Container buildPaletteResult(double theHeight, double theWidth,
    BuildContext context, void Function(Map) paletteResultSetState, Map data) {
  Color contrast;
  if (data["bestContrast"] == "black")
    contrast = Colors.black;
  else
    contrast = Colors.white;

  return Container(
    width: theWidth,
    height: theHeight,
    decoration: BoxDecoration(
        color: Color.fromARGB(
            255, data["rgb"]["r"], data["rgb"]["g"], data["rgb"]["b"]),
        borderRadius: BorderRadius.circular(50)),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          "${data["name"]} \n${data["hex"]} \n${buildColorAttributes(data, useRGB)}",
          style:
              Theme.of(context).textTheme.bodyMedium?.copyWith(color: contrast),
          textAlign: TextAlign.center,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              width: 75,
              height: 50,
              decoration: BoxDecoration(
                  color: Colors.black, borderRadius: BorderRadius.circular(15)),
            ),
            GestureDetector(
              onTap: () {
                paletteResultSetState(data);
              },
              child: Icon(
                Icons.search,
                size: 50,
                color: contrast,
              ),
            ),
            Container(
              width: 75,
              height: 50,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(15)),
            ),

            ///GestureDetector(
            ///  onTap: () {},
            ///  child: Icon(Icons.star_border, size: 50, color: contrast),
            ///)
          ],
        )
      ],
    ),
  );
}

/**
 * Builds a Container to be placed in the "Other Closest Colors" menu,
 * with all the color attributes of the given data.
 *
 * @author L Mavroudakis
 * @version 1.0.0
 * @param data - parsed JSON data for color to create Container based on
 */
Padding buildClosestResult(
    Map data,
    BuildContext context,
    void Function(bool) updateMenuState,
    void Function(bool) updateMainColor,
    void Function(Color) closestResultSetState,
    void Function(dynamic) launchHTTPSetState) {
  Color contrast = parseBestContrast(data["bestContrast"], false);
  Color inverseContrast = parseBestContrast(data["bestContrast"], true);
  Color contrastTransparent;
  Color inverseContrastTransparent;
  Color theColor = HexColor(data["hex"]);

  int backgroundOpacity = 192;

  if (contrast == Colors.black) {
    contrastTransparent = Color.fromARGB(backgroundOpacity, 0, 0, 0);
    inverseContrastTransparent =
        Color.fromARGB(backgroundOpacity, 255, 255, 255);
  } else {
    inverseContrastTransparent = Color.fromARGB(backgroundOpacity, 0, 0, 0);
    contrastTransparent = Color.fromARGB(backgroundOpacity, 255, 255, 255);
  }

  return Padding(
    padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
    child: Container(
      width: MediaQuery.sizeOf(context).width,
      decoration: BoxDecoration(
          color: theColor,
          border: Border(
              left: BorderSide(color: Colors.black, width: 5),
              bottom: BorderSide(color: Colors.black, width: 5),
              right: BorderSide(color: Colors.white, width: 5),
              top: BorderSide(color: Colors.white, width: 5))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsets.all(15.0),
            child: Container(
              width: MediaQuery.sizeOf(context).width - 200,
              child: Text(
                "\"${data["name"]}\"",
                softWrap: true,
                style: Theme.of(context)
                    .textTheme
                    .displayMedium
                    ?.copyWith(color: contrast),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 20.0, top: 10, bottom: 10),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    showDialog(
                      barrierDismissible: false,
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          backgroundColor: contrastTransparent,
                          shape: RoundedRectangleBorder(
                              side: BorderSide(color: theColor, width: 10),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(12))),
                          title: Column(children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Icon(
                                    Icons.close,
                                    color: inverseContrast,
                                    size: 60,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    updateMenuState(false);
                                    currentColor = Color.fromARGB(
                                        255,
                                        data["rgb"]["r"],
                                        data["rgb"]["g"],
                                        data["rgb"]["b"]);
                                    updateMainColor(true);
                                    launchHTTP(launchHTTPSetState);
                                    Navigator.pop(context);
                                  },
                                  child: Icon(
                                    Icons.search,
                                    color: inverseContrast,
                                    size: 60,
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 10.0),
                              child: Text(
                                "\"${data["name"]}\"",
                                textAlign: TextAlign.center,
                                style: Theme.of(context)
                                    .textTheme
                                    .displayMedium
                                    ?.copyWith(
                                        color: inverseContrast,
                                        fontWeight: FontWeight.bold),
                              ),
                            ),
                          ]),
                          content: OverflowBox(
                            maxHeight: double.infinity,
                            child: Column(
                              children: [
                                Stack(
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                        padding: EdgeInsets.only(top: 6),
                                        child: Container(
                                          height: 272,
                                          width: 272,
                                          decoration: BoxDecoration(
                                              color: inverseContrast,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(20))),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                          padding: EdgeInsets.only(top: 16),
                                          child: Container(
                                            height: 252,
                                            width: 252,
                                            decoration: BoxDecoration(
                                                color: theColor,
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(20))),
                                            child: Align(
                                              alignment: Alignment.center,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    width: 100,
                                                    height: 100,
                                                    decoration: BoxDecoration(
                                                        color: Colors.black,
                                                        borderRadius:
                                                            BorderRadius.only(
                                                                topLeft: Radius
                                                                    .circular(
                                                                        20),
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        20))),
                                                  ),
                                                  Container(
                                                    width: 100,
                                                    height: 100,
                                                    decoration: BoxDecoration(
                                                        color: Colors.white,
                                                        borderRadius:
                                                            BorderRadius.only(
                                                                topRight: Radius
                                                                    .circular(
                                                                        20),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        20))),
                                                  )
                                                ],
                                              ),
                                            ),
                                          )),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  width: 292,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        top: 24, left: 10, right: 10),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 12.0),
                                            child: Column(
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          bottom: 8.0),
                                                  child: Text(
                                                    "${data["hex"]}",
                                                    textAlign: TextAlign.center,
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .displayMedium
                                                        ?.copyWith(
                                                            color:
                                                                inverseContrast),
                                                  ),
                                                ),
                                                ElevatedButton(
                                                    style: ButtonStyle(
                                                        backgroundColor:
                                                            WidgetStatePropertyAll(
                                                                inverseContrastTransparent)),
                                                    onPressed: () {
                                                      Clipboard.setData(
                                                          ClipboardData(
                                                              text:
                                                                  "${data["hex"]}"));
                                                    },
                                                    child: Text("Copy",
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .displayMedium
                                                            ?.copyWith(
                                                                color:
                                                                    contrast)))
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 12.0),
                                            child: Column(
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          bottom: 8.0),
                                                  child: Text(
                                                    "RGB( ${data["rgb"]["r"]}, ${data["rgb"]["g"]}, ${data["rgb"]["b"]} )",
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .displayMedium
                                                        ?.copyWith(
                                                            color:
                                                                inverseContrast),
                                                  ),
                                                ),
                                                ElevatedButton(
                                                    style: ButtonStyle(
                                                        backgroundColor:
                                                            WidgetStatePropertyAll(
                                                                inverseContrastTransparent)),
                                                    onPressed: () {
                                                      Clipboard.setData(
                                                          ClipboardData(
                                                              text:
                                                                  "RGB( ${data["rgb"]["r"]}, ${data["rgb"]["g"]}, ${data["rgb"]["b"]} )"));
                                                    },
                                                    child: Text("Copy",
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .displayMedium
                                                            ?.copyWith(
                                                                color:
                                                                    contrast)))
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 12.0),
                                            child: Column(
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            bottom: 8.0),
                                                    child: Text(
                                                      "HSL( ${data["hsl"]["h"]}, ${data["hsl"]["s"]}, ${data["hsl"]["l"]} )",
                                                      textAlign: TextAlign.left,
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .displayMedium
                                                          ?.copyWith(
                                                              color:
                                                                  inverseContrast),
                                                    ),
                                                  ),
                                                ),
                                                ElevatedButton(
                                                    style: ButtonStyle(
                                                        backgroundColor:
                                                            WidgetStatePropertyAll(
                                                                inverseContrastTransparent)),
                                                    onPressed: () {
                                                      Clipboard.setData(
                                                          ClipboardData(
                                                              text:
                                                                  "HSL( ${data["hsl"]["h"]}, ${data["hsl"]["s"]}, ${data["hsl"]["l"]} )"));
                                                    },
                                                    child: Text("Copy",
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .displayMedium
                                                            ?.copyWith(
                                                                color:
                                                                    contrast)))
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          actions: [],
                        );
                      },
                    );
                  },
                  child: Icon(
                    Icons.fullscreen,
                    size: 60,
                    color: contrast,
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    closestResultSetState(theColor);
                  },
                  child: Icon(
                    Icons.search,
                    size: 60,
                    color: contrast,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    ),
  );
}

/**
 * Builds the text to be placed into areas where Containers only show 
 * one or the other color attribute group (RGB/HSL), to assign such
 * to the widget being updated when RGB/HSL is swapped between with the
 * button in the AppBar.
 *
 * @author L Mavroudakis
 * @version 1.0.0
 * @param data - parsed JSON data for color to create attribute String based on
 */
String buildColorAttributes(Map data, bool useRGB) {
  if (useRGB)
    return "RGB(${data["rgb"]["r"]},${data["rgb"]["g"]},${data["rgb"]["b"]})";
  else
    return "HSL(${data["hsl"]["h"].toStringAsFixed(0)}°,${data["hsl"]["s"].toStringAsFixed(0)}%,${data["hsl"]["l"].toStringAsFixed(0)}%)";
}
