import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_color_utils/flutter_color_utils.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'dart:convert';

void main() {
  runApp(const MainApp());
}

/// maybe probably to-do
/// - DOCUMENTATION
/// - name list descriptions in dropdown selection with info button for each
/// - MAKE SURE palette colors scroll height is good in other emulators

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: MyProject(),
        theme: ThemeData(
            textTheme: TextTheme(
                displaySmall:
                    TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                displayLarge:
                    TextStyle(fontWeight: FontWeight.w400, fontSize: 35),
                displayMedium:
                    TextStyle(fontWeight: FontWeight.w500, fontSize: 27),
                bodyMedium:
                    TextStyle(fontWeight: FontWeight.bold, fontSize: 22))));
  }
}

class MyProject extends StatefulWidget {
  const MyProject({super.key});

  @override
  State<MyProject> createState() => _MyProjectState();
}

class _MyProjectState extends State<MyProject> {
  Color pickerColor = Color(0xFFB76E79);
  Color currentColor = Color(0xFFB76E79);
  bool showColorPicker = false;
  Stack theColorPicker = Stack();
  String currColorAttributes = "";
  bool useRGB = true;
  ColorModel currColorModel = ColorModel.rgb;
  String colorModelText = "Swap to HSL";
  Color searchContrast = Colors.black;

  bool resultsReady = false;

  String? selectedListKey = "default";

  String currColorHex = "";
  String complColorHex = "";
  String triadColorHex1 = "";
  String triadColorHex2 = "";
  String tetradColorHex1 = "";
  String tetradColorHex2 = "";
  String tetradColorHex3 = "";

  Map closestColor = Map();
  Map complimentaryColor = Map();
  Map triadicColor1 = Map();
  Map triadicColor2 = Map();
  Map tetradicColor1 = Map();
  Map tetradicColor2 = Map();
  Map tetradicColor3 = Map();

  HSLColor currHSL = HSLColor.fromColor(const Color(0xFFB76E79));
  HSLColor complHSL = HSLColor.fromColor(const Color(0xFFB76E79));
  HSLColor triadHSL1 = HSLColor.fromColor(const Color(0xFFB76E79));
  HSLColor triadHSL2 = HSLColor.fromColor(const Color(0xFFB76E79));
  HSLColor tetradHSL1 = HSLColor.fromColor(const Color(0xFFB76E79));
  HSLColor tetradHSL2 = HSLColor.fromColor(const Color(0xFFB76E79));
  HSLColor tetradHSL3 = HSLColor.fromColor(const Color(0xFFB76E79));

  Container closestContainer = Container();
  Container complimentaryContainer = Container();
  Container triadicContainer1 = Container();
  Container triadicContainer2 = Container();
  Container tetradicContainer1 = Container();
  Container tetradicContainer2 = Container();
  Container tetradicContainer3 = Container();

  Map colorJsonTemplate() {
    return {
      "name": "Test",
      "hex": "#aaaaaa",
      "rgb": {"r": 1, "g": 1, "b": 1},
      "hsl": {"h": 1, "s": 1.1, "l": 1.1},
      "lab": {"l": 1.1, "a": -1.1, "b": -1.1},
      "luminance": 1,
      "luminanceWCAG": 1.1,
      "bestContrast": "black",
      "swatchImg": {
        "svgNamed": "/v1/swatch/?color=1ecbe1&name=Caribbean%20Blue",
        "svg": "/v1/swatch/?color=1ecbe1"
      },
      "requestedHex": "#ffffff",
      "distance": 0
    };
  }

  var nameLists = [
    const DropdownMenuItem(
        value: "default", child: Text("Handpicked Color Names (ALL Lists)")),
    const DropdownMenuItem(value: "basic", child: Text("Basic")),
    const DropdownMenuItem(value: "html", child: Text("HTML Colors")),
    const DropdownMenuItem(
        value: "japaneseTraditional",
        child: Text("Traditional Colors of Japan")),
    const DropdownMenuItem(value: "leCorbusier", child: Text("Le Corbusier")),
    const DropdownMenuItem(
        value: "nbsIscc", child: Text("The Universal Color Language")),
    const DropdownMenuItem(value: "ntc", child: Text("NTC.js")),
    const DropdownMenuItem(value: "osxcrayons", child: Text("OS X Crayons")),
    const DropdownMenuItem(value: "ral", child: Text("RAL Color")),
    const DropdownMenuItem(
        value: "ridgway",
        child: Text("Robert Ridgway's Color Standards and Color Nomenclature")),
    const DropdownMenuItem(
        value: "sanzoWadaI",
        child: Text("Wada Sanzō Japanese Color Dictionary Volume I")),
    const DropdownMenuItem(
        value: "thesaurus", child: Text("The Color Thesaurus")),
    const DropdownMenuItem(
        value: "werner", child: Text("Werner's Nomenclature of Colours")),
    const DropdownMenuItem(
        value: "windows", child: Text("Microsoft Windows Color Names")),
    const DropdownMenuItem(
        value: "wikipedia", child: Text("Wikipedia Color Names")),
    const DropdownMenuItem(value: "french", child: Text("French Colors")),
    const DropdownMenuItem(value: "spanish", child: Text("Spanish Colors")),
    const DropdownMenuItem(value: "german", child: Text("German Colors")),
    const DropdownMenuItem(value: "x11", child: Text("X11 Color Names")),
    const DropdownMenuItem(value: "xkcd", child: Text("XKCD Colors")),
    const DropdownMenuItem(value: "risograph", child: Text("Risograph Colors")),
    const DropdownMenuItem(
        value: "chineseTraditional",
        child: Text("Traditional Colors of China")),
    const DropdownMenuItem(value: "bestOf", child: Text("Best of Color Names")),
    const DropdownMenuItem(value: "short", child: Text("Short Color Names")),
  ];

  void changePickerColor(Color color) {
    setState(() => pickerColor = color);
  }

  void toggleRGBorHSL() {
    setState(() {
      if (useRGB) {
        useRGB = false;
        currColorAttributes =
            "HSL(${currHSL.hue.toStringAsFixed(0)}°,${(currHSL.saturation * 100).toStringAsFixed(0)}%,${(currHSL.lightness * 100).toStringAsFixed(0)}%)";
        currColorModel = ColorModel.hsl;
        colorModelText = "Swap to RGB";
      } else {
        useRGB = true;
        currColorAttributes =
            "RGB(${currentColor.red},${currentColor.green},${currentColor.blue})";
        currColorModel = ColorModel.rgb;
        colorModelText = "Swap to HSL";
      }
      updatePaletteResults();
    });
  }

  void updateMainColor(bool useInputAttributes) {
    setState(() {
      if (!useInputAttributes) currentColor = pickerColor;
      currHSL = HSLColor.fromColor(currentColor);
      if (useRGB)
        currColorAttributes =
            "RGB(${currentColor.red},${currentColor.green},${currentColor.blue})";
      else
        currColorAttributes =
            "HSL(${currHSL.hue.toStringAsFixed(0)}°,${(currHSL.saturation * 100).toStringAsFixed(0)}%,${(currHSL.lightness * 100).toStringAsFixed(0)}%)";
      currColorHex = "#${colorToHex(currentColor).substring(2).toLowerCase()}";
    });
  }

  void updateSearchContrast() async {
    setState(() {
      if (currHSL.lightness * 100 <= 50)
        searchContrast = Colors.white;
      else
        searchContrast = Colors.black;
    });

    String link =
        "https://api.color.pizza/v1/?values=${colorToHex(currentColor).substring(2).toLowerCase()}&list=default";

    var response = await http.get(Uri.parse(link));

    if (response.statusCode == 200) {
      setState(() {
        var data = jsonDecode(response.body);

        if (data["colors"][0]["bestContrast"] == "black")
          searchContrast = Colors.black;
        else
          searchContrast = Colors.white;
      });
    } else {
      print("ERROR: $response.statusCode");
    }
  }

  Container buildPaletteResult(double theHeight, double theWidth, Map data) {
    try {
      print(data["rgb"]["r"]);
    } catch (e) {
      data = colorJsonTemplate();
    }
    Color contrast;
    if (data["bestContrast"] == "black")
      contrast = Colors.black;
    else
      contrast = Colors.white;

    return Container(
      width: theWidth,
      height: theHeight,
      decoration: BoxDecoration(
          color: Color.fromARGB(
              255, data["rgb"]["r"], data["rgb"]["g"], data["rgb"]["b"]),
          borderRadius: BorderRadius.circular(50)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "${data["name"]} \n${data["hex"]} \n${buildColorAttributes(data)}",
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(color: contrast),
            textAlign: TextAlign.center,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                width: 75,
                height: 50,
                decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(15)),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    resultsReady = false;
                    currentColor = Color.fromARGB(255, data["rgb"]["r"],
                        data["rgb"]["g"], data["rgb"]["b"]);
                    updateMainColor(true);
                    launchHTTP();
                  });
                },
                child: Icon(
                  Icons.search,
                  size: 50,
                  color: contrast,
                ),
              ),
              Container(
                width: 75,
                height: 50,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)),
              ),

              ///GestureDetector(
              ///  onTap: () {},
              ///  child: Icon(Icons.star_border, size: 50, color: contrast),
              ///)
            ],
          )
        ],
      ),
    );
  }

  String buildColorAttributes(Map data) {
    if (useRGB)
      return "RGB(${data["rgb"]["r"]},${data["rgb"]["g"]},${data["rgb"]["b"]})";
    else
      return "HSL(${data["hsl"]["h"].toStringAsFixed(0)}°,${data["hsl"]["s"].toStringAsFixed(0)}%,${data["hsl"]["l"].toStringAsFixed(0)}%)";
  }

  void launchHTTP() async {
    String link =
        "https://api.color.pizza/v1/?values=${colorToHex(currentColor).substring(2).toLowerCase()}&list=$selectedListKey";

    var response = await http.get(Uri.parse(link));

    if (response.statusCode == 200) {
      setState(() {
        closestColor = jsonDecode(response.body)["colors"][0];
        print(closestColor);

        complHSL = HSLColor.fromAHSL(1, (currHSL.hue + 180) % 360,
            currHSL.saturation, currHSL.lightness);
        triadHSL1 = HSLColor.fromAHSL(1, (currHSL.hue + 120) % 360,
            currHSL.saturation, currHSL.lightness);
        triadHSL2 = HSLColor.fromAHSL(1, (currHSL.hue + 240) % 360,
            currHSL.saturation, currHSL.lightness);
        tetradHSL1 = HSLColor.fromAHSL(
            1, (currHSL.hue + 90) % 360, currHSL.saturation, currHSL.lightness);
        tetradHSL2 = HSLColor.fromAHSL(1, (currHSL.hue + 180) % 360,
            currHSL.saturation, currHSL.lightness);
        tetradHSL3 = HSLColor.fromAHSL(1, (currHSL.hue + 270) % 360,
            currHSL.saturation, currHSL.lightness);
        complColorHex = colorToHex(complHSL.toColor()).substring(2);
        triadColorHex1 = colorToHex(triadHSL1.toColor()).substring(2);
        triadColorHex2 = colorToHex(triadHSL2.toColor()).substring(2);
        tetradColorHex1 = colorToHex(tetradHSL1.toColor()).substring(2);
        tetradColorHex2 = colorToHex(tetradHSL2.toColor()).substring(2);
        tetradColorHex3 = colorToHex(tetradHSL3.toColor()).substring(2);

        secondaryHTTP();
      });
    } else {
      print("ERROR: $response.statusCode");
    }
  }

  void secondaryHTTP() async {
    String link =
        "https://api.color.pizza/v1/?values=${complColorHex.toLowerCase()},${triadColorHex1.toLowerCase()},${triadColorHex2.toLowerCase()},${tetradColorHex1.toLowerCase()},${tetradColorHex2.toLowerCase()},${tetradColorHex3.toLowerCase()}&list=$selectedListKey";

    var response = await http.get(Uri.parse(link));

    if (response.statusCode == 200) {
      Map data = jsonDecode(response.body);
      complimentaryColor = data["colors"][0];
      triadicColor1 = data["colors"][1];
      triadicColor2 = data["colors"][2];
      tetradicColor1 = data["colors"][3];
      tetradicColor2 = data["colors"][4];
      tetradicColor3 = data["colors"][5];
      setState(await () {
        updateSearchContrast();
        updatePaletteResults();
      });
      resultsReady = true;
    } else {
      print("ERROR: $response.statusCode");
    }
  }

  void updatePaletteResults() {
    closestContainer = buildPaletteResult(200, 300, closestColor);
    complimentaryContainer = buildPaletteResult(200, 300, complimentaryColor);
    triadicContainer1 = buildPaletteResult(200, 300, triadicColor1);
    triadicContainer2 = buildPaletteResult(200, 300, triadicColor2);
    tetradicContainer1 = buildPaletteResult(200, 300, tetradicColor1);
    tetradicContainer2 = buildPaletteResult(200, 300, tetradicColor2);
    tetradicContainer3 = buildPaletteResult(200, 300, tetradicColor3);
  }

  @override
  void initState() {
    super.initState();
    updateMainColor(true);
    launchHTTP();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 35.0),
                child: ElevatedButton(
                    onPressed: toggleRGBorHSL, child: Text(colorModelText)),
              )
            ],
            title: Text(
              "Name Your Palette",
              style: TextStyle(color: Colors.white),
            ),
            backgroundColor: Colors.grey[700],
          ),
          body: Stack(
            children: [
              Container(
                height: double.infinity,
                width: double.infinity,
                color: Colors.grey,
              ),
              Column(
                children: [
                  Container(
                    alignment: Alignment.topCenter,
                    width: double.infinity,
                    height: 210,
                    color: const Color.fromARGB(255, 212, 212, 212),
                    child: Column(
                      children: [
                        Padding(
                          padding:
                              const EdgeInsets.only(top: 10.0, bottom: 10.0),
                          child: Text(
                            "Selected Color:",
                            style: Theme.of(context).textTheme.displayLarge,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: Container(
                                width: 225,
                                height: 50,
                                decoration: BoxDecoration(
                                    color: currentColor,
                                    border: Border(
                                        left: BorderSide(
                                            color: Colors.black, width: 5),
                                        bottom: BorderSide(
                                            color: Colors.black, width: 5),
                                        right: BorderSide(
                                            color: Colors.white, width: 5),
                                        top: BorderSide(
                                            color: Colors.white, width: 5))),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(left: 10.0),
                                      child: Text(
                                        currColorHex,
                                        style: TextStyle(
                                            color: searchContrast,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12),
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(right: 10.0),
                                      child: Text(
                                        currColorAttributes,
                                        style: TextStyle(
                                            color: searchContrast,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  pickerColor = currentColor;
                                  showColorPicker = true;
                                });
                              },
                              style: ButtonStyle(
                                backgroundColor:
                                    WidgetStatePropertyAll(Colors.grey),
                              ),
                              child: Text(
                                "CHANGE COLOR",
                                style: TextStyle(color: Colors.white),
                              ),
                            )
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 12.0),
                                child: Text(
                                  "Source \nName List(s):",
                                  style:
                                      Theme.of(context).textTheme.displayMedium,
                                ),
                              ),
                              Container(
                                width: 200,
                                color: Colors.white,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 20.0),
                                  child: DropdownButton(
                                    isExpanded: true,
                                    value: "$selectedListKey",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16),
                                    menuWidth: 300,
                                    itemHeight: 75,
                                    items: nameLists,
                                    onChanged: (selected) {
                                      setState(() {
                                        selectedListKey = selected;
                                        setState(() {
                                          resultsReady = false;
                                          showColorPicker = false;
                                          updateMainColor(true);
                                          launchHTTP();
                                        });
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  Stack(children: [
                    Visibility(
                      visible: resultsReady,
                      child: Container(
                        height: MediaQuery.sizeOf(context).height - 318,
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Text(
                                  "Closest Color:",
                                  style:
                                      Theme.of(context).textTheme.displayMedium,
                                ),
                              ),
                              closestContainer,
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Text(
                                  "Closest Complimentary:",
                                  style:
                                      Theme.of(context).textTheme.displayMedium,
                                ),
                              ),
                              complimentaryContainer,
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Text(
                                  "Closest Triadic Counterparts:",
                                  style:
                                      Theme.of(context).textTheme.displayMedium,
                                ),
                              ),
                              triadicContainer1,
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: triadicContainer2,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Text(
                                  "Closest Tetradic Counterparts:",
                                  style:
                                      Theme.of(context).textTheme.displayMedium,
                                ),
                              ),
                              tetradicContainer1,
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: tetradicContainer2,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: tetradicContainer3,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Visibility(
                        visible: !resultsReady,
                        child: Image.network(
                            "https://www.appseconnect.com/wp-content/uploads/2017/08/loader.gif"))
                  ])
                ],
              ),
              Visibility(
                visible: showColorPicker,
                child: Stack(children: [
                  Container(
                    height: MediaQuery.sizeOf(context).height,
                    width: MediaQuery.sizeOf(context).width,
                    color: Color.fromARGB(128, 0, 0, 0),
                  ),
                  OverflowBox(
                    maxHeight: double.infinity,
                    child: Stack(children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          width: 370,
                          height: 700,
                          decoration: BoxDecoration(
                              color: Color.fromARGB(196, 255, 255, 255),
                              border: Border.all(color: pickerColor, width: 20),
                              borderRadius: BorderRadius.circular(20)),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 40.0),
                          child: Container(
                            width: 300,
                            height: 660,
                            color: Colors.transparent,
                            child: OverflowBox(
                              maxHeight: double.infinity,
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              pickerColor = currentColor;
                                              showColorPicker = false;
                                            });
                                          },
                                          child: Icon(
                                            Icons.close,
                                            size: 80,
                                            color: Colors.black,
                                          )),
                                      GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              resultsReady = false;
                                              showColorPicker = false;
                                              updateMainColor(false);
                                              launchHTTP();
                                            });
                                          },
                                          child: Icon(
                                            Icons.search,
                                            size: 80,
                                            color: Colors.black,
                                          ))
                                    ],
                                  ),
                                  HueRingPicker(
                                    pickerColor: pickerColor,
                                    onColorChanged: changePickerColor,
                                    displayThumbColor: true,
                                    enableAlpha: false,
                                  ),
                                  SlidePicker(
                                    pickerColor: pickerColor,
                                    onColorChanged: changePickerColor,
                                    enableAlpha: false,
                                    sliderSize: Size(300, 50),
                                    showIndicator: false,
                                    sliderTextStyle: Theme.of(context)
                                        .textTheme
                                        .displaySmall,
                                    colorModel: currColorModel,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ]),
                  ),
                ]),
              )
            ],
          )),
    );
  }
}
